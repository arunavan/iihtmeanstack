function  validate()
  {
   if(document.f.p1.value.length<4)
     alert(" id should be more than 4 characters");
   if(document.f.p2.value.length<6)
     alert(" password should be more than 6 characters");
  }